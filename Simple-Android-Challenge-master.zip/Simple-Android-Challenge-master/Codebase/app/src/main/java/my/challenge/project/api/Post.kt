package my.challenge.project.api

data class Post(

    val userId: Long,
    val id: Long,
    val title: String,
    val body: String
)
